## Script 4: Estimation

## Set the parameters for simulation
## The coefficient for the input
alpha <- 2.4
## The standard deviance of the white noise (square root of the variance)
sigma <- 0.5
## Number of points
N <- 100
## Generate the input as a sine
x <- sin(seq(0,4*pi,len=N))
## Simulate the model
y <- alpha*x + rnorm(N,0,sigma)
## Plot
par(mfrow=c(2,1))
plot(x,type="l")
plot(y,type="l")
## Question: Plot a scatter plot of x vs. y to see their functional relation.
## Estimate the parameters with matrix calculations
## Set up the X matrix: a column of
X <- matrix(x,ncol=1)
## And the Y matrix
Y <- matrix(y,ncol=1)
## Calculate the parameters theta, in this case only consisting of alpha.
## The function solve() is used for matrix division
theta <- solve( t(X) %*% X, t(X) %*% Y)
theta

## Or use the lm() function for the same
## Set the data into a data.frame
D <- data.frame(x=x,y=y)
## First argument is the model formula and second is the data, see ?lm and 
## ?formula for further info
fit <- lm(y ~ 0 + x, data=D)
## Write out the result
summary(fit)
## Investigate the uncertainty of parameter estimates

## Calculate an estimate of the variance (sigma^2) of the error noise process
## The sum of squared residuals
S <- t(Y - X%*%theta) %*% (Y - X%*%theta)
hatVarEps <- S/(N-1)
## Then use this to calculate the standard error (standard deviance of the 
## parameter estimates theta)
sqrt(hatVarEps %*% solve(t(X)%*%X, 1))

## Or see it from the result returned by the lm() function
fit <- lm(y ~ 0 + x, data=D)
## As the "Std. Error"
summary(fit)
## This is one of the fantastic features of statistics, not only is 
## the value of the model parameters estimated, but also the parameter 
## uncertainty. But what is the meaning of the "Std. Error"?

## Under the assumed conditions (i.i.d. residuals) the parameter estimates 
## are approximately   normal distributed, which enable us to construct 
## confidence bands.

## Try to ``see'' that the parameter estimates are normal distributed by 
## repeating the simulation and estimation.
## Repeat Nrep times
Nrep <- 500
## Number of samples
N <- 100
## For keeping the estimates
HatAlpha <- numeric(Nrep)
## Repeat
for(i in 1:Nrep){
  ## Simulate the model
  y <- alpha*x + rnorm(N,0,sigma)
  ## Estimate the parameters
  fit <- lm(y ~ 0 + x, data=data.frame(x,y))
  ## Keep the estimate
  HatAlpha[i] <- fit$coefficients["x"]
}
## Now see the distribution of the estimates
hist(HatAlpha,probability=TRUE)
## Draw the estimated distribution of Theta from the last fit
tmp <- seq(2,2.8,by=0.01)
xStdError <- summary(fit)$coefficients["x","Std. Error"]
lines(tmp, dnorm(tmp,mean=fit$coefficients["x"],sd=xStdError), col=2)
## A 95% confidence band is
fit$coefficients["x"] + 1.97 * c(-xStdError,xStdError)
## Question: Try to vary the number of generated samples (\ie N). 
## How does this affect the uncertainty of the estimates?

## Question: Is it true that the real parameter value falls inside the 95%  
## confidence band in average 95% of the time? Verify by repeating the 
## simulations.

## Question: Extend the simulation model by adding an intercept 
## Y_t = \mu + \alpha X_t + \vareps_t
## and generate the data again. 
## Now estimate the parameters either with matrix calculations (a column of 
## ones must be added to the X matrix) or with the lm() function (the 0 
## must be changed to a 1 in the formula or leaved out).

## Question: Try to investigate the impact of not using the right (suitable) 
## model for estimation, are the parameter estimates be un-biased?
## Set the parameters for simulation
## The coefficient for the input
alpha <- 2.4
## The standard deviance of the white noise (square root of the variance)
sigma <- 0.4
## Number of points
N <- 100
## Generate the input as a sine
x <- sin(seq(0,4*pi,len=N))
## Simulate the model
y <- alpha*x + rnorm(N,0,sigma)
## Plot
par(mfrow=c(2,1))
plot(x,type="l")
plot(y,type="l")
## Now data is available, hence the likelihood can be calculated. For the this 
## the pdf is needed. In R the pdf (and cdf,quantiles and random numbers) from 
## many distributions can easily be obtained. In this case we need the normal pdf.

## As an example plot the pdf of the normal distribution with mean=2 (mu) 
## and standard deviation=3 (sigma)
## See ?dnorm for more info
xseq <- seq(-15,15,by=0.1)
plot(xseq, dnorm(xseq,mean=2,sd=3), type="l")
## Now carry out maximum likelihood estimation of the two parameters

## Define a function which return the negative log-likelihood for the model.
## Note the first argument to the function it must be the vector of parameters
negloglik <- function(theta,x,y){
  ## theta are the two parameters
  alpha <- theta[1]
  sigma <- theta[2]
  ## Calculate the residuals
  res <- y - alpha*x
  ## With the normal pdf calculate the negative loglikelihood
  -sum(log(dnorm(res,sd=sigma)))
}
## Use an optimizer to minimize the function. 
## First argument is the initial values of the parameters and then the 
## function plus additional arguments to the function
fit <- optim(par=c(1,1), negloglik, x=x, y=y)
## See that fit is a list and what is in it
str(fit)
## The parameter estimates are
fit$par
## Actually when the error is a white noise process, then the ML estimates and 
## the LS estimates of the parameters are equal, except for the estimate of the 
## standard deviance (sigma) of the error process
fitlm <- lm(y~0+x)
## See that the slope parameter (alpha, here named x) estimates are equal
summary(fitlm)
## The standard deviance are found by
sd(fitlm$residuals)
## Which is slightly different from the ML estimate, however this a marginal 
## difference and can only play a role if only few samples are available (N<30)

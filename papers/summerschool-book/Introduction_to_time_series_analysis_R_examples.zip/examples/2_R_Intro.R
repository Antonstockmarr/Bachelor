## Script 2: R Intro

## A line starting with a # is a comment and will not be executed by R

## Run the next line to set a variable x. In RStudio the line can be 
## run by pressing "Ctrl-Enter", other code runinng commands 
## see menu "Code->Run Region"
x <- 1
## See the value of x
x
## All variables i R has a class
class(x)
## To read the help of numeric
?numeric
## The R help can also be searched by e.g.
??regression
## Create a floating point of length 100
x <- numeric(100)
x
## Other basic elements, check the "see also" section and 
## "examples" in bottom of the page
?integer
?logical
?character
## Combine elements into a vector
c(1,4.2,-8)
c("this","is","a","vector","or","array","of","characters")
## Paste them into one character 
paste("this","is","a","single","character","element")
## An integer sequence
1:10
## A sequence
seq(-2,2,by=0.1)
## The usual way of handling a data set is with a data.frame, which is 
## simply as a table in a spreadsheet program, i.e. a two-dimensional matrix
## Make a data.frame with three columns
X <- data.frame(t=1:10,y1=seq(1,0,len=10),y2=seq(-2,5,len=10))
class(X)
## The entire data.frame
X
## The first rows
head(X)
## The last rows
tail(X)
## The columns have names
names(X)
## The columns have different classes. Column 't' is an integer and the 
## others are numeric
str(X)
## Access one column
X$y1
## In RStudio try auto-completion, put the cursor in front of the 
## dollar sign and press "tab"
X$

## Take a subset of the data.frame
X[,c("t","y2")]
## Take the two first columns
X[,c(1,2)]
## Take all, but second and third columns (negative indexes remove)
X[,c(-2,-3)]
## Take row 4 to 8
X[4:8,]
## Index with a TRUE-FALSE statement
X$y1 < 0.5
X[X$y1 < 0.5,]
## Operations are element wise (opposed to Matlab)
sqrt(X[,c("y1","y2")] * X[,c("y1","y2")])
## Matrix operations are with "%" around, and transpose is with t()
as.matrix(X[,c("y1","y2")]) %*% t(as.matrix(X[,c("y1","y2")]))

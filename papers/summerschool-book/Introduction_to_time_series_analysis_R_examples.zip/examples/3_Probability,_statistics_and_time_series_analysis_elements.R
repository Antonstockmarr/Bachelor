## Script 3: Probability, statistics and time series analysis elements

## Generate N values from a normal distribution with mean and sd (standard deviance)
N <- 100
y <- rnorm(N,mean=2,sd=2)
## The average (or sample mean)
mean(y)
## The sample variance
var(y)
## The sample standard deviance
sd(y)
sqrt(var(y))
## The Beta distribution (shape1 is alpha and shape2 is beta)
x <- rbeta(N, shape1=2, shape2=3)
## The average (or sample mean)
mean(x)
## The sample variance
var(x)
## The sample standard deviance
sd(x)
## Example: Backshift operator and ACF

## Make a series of N values
N <- 8
## Set x to the values 1,2,...,N
x <- 1:N
## Lag (back-shift) x one step
c(NA,x[1:(N-1)])
## Print to see x versus x lagged k step
k <- 2
data.frame(x, x.l2=x[c(rep(NA,k),x[1:(N-k)])])
## Define a helping function for lagging
lagVec <- function(x,k){
  ## Shift the x vector k steps to the right
  c(rep(NA,k),x[1:(length(x)-k)])
}
## Test the function
lagVec(x,k=1)
## Investigate the ACF.
## A numeric (vector) of length N
  N <- 100
x <- numeric(N)
## For each time point (here i) take 0.8 of the previous value and
## add a random number
x[1] <- rnorm(1)
for(i in 2:N){
  x[i] <- 0.8 * x[i-1] + rnorm(1)
}
## Plot it
plot(x, type="l", xlab="t")
## Then plot it versus lagged versions to see how the spread of 
## the points increase as the lag increase
par(mfrow=c(1,3))
plot(x,x)
plot(x, lagVec(x,1))
plot(x, lagVec(x,2))
## Now the ACF can be calculated by
cor(x,lagVec(x,0),use="complete.obs")
cor(x,lagVec(x,1),use="complete.obs")
cor(x,lagVec(x,2),use="complete.obs")
## go on, or simply call the function
acf(x)
## See how the values of the correlations for different lags are equal to the 
## bars in the acf() plot. The blue lines indicate a 95% confidence band.
## First a white noise time series is generated
N <- 200
x <- rnorm(N)
plot(x,type="l")
## Then plot the sequence versus the sequence lagged: zero, one and two steps
par(mfrow=c(1,3))
plot(x,x)
k <- 1
plot(x,lagVec(x,k))
k <- 2
plot(x,lagVec(x,k))
## Calculate the ACF for the generated white noise
acf(x)
## Set a vector of time
time <- seq(0,4*pi,len=200)
## Make a sine
x <- sin(time)
## Plots it
plot(x, type="l")
## The ACF of a sine is a sine
acf(x,lag.max=40)
## Add two outliers
x[10] <- 20
x[50] <- -20
## Plots it
plot(x, type="l")
## The ACF
acf(x)
## see that the ACF is non-significant as for white noise, however 
## the series is certainly is not white noise
## Number of samples
N <- 100
## A little function for simulation of an AR(1) process
simAR1 <- function(phi1, N, Nburnin=30){
  ## Do Nburnin points as a burn-in period
  Nsim <- N+Nburnin
  ## White noise
  x <- rnorm(Nsim)
  ## Output vector
  y <- numeric(Nsim)
  ## Simulate
  for(i in 2:Nsim){
    y[i] <- phi1*y[i-1] + x[i]
  }
  ## Remove the burn-in period
  y <- y[-1:-Nburnin]
  return(y)
}
## Simulate the process, when it is stationary
y <- simAR1(phi1=0.95,N=100)
## An exponential decaying ACF indicates an AR process
par(mfrow=c(2,1))
plot(y, type="l", xlab="t")
acf(y, lag.max=100)
## Question: Try changing the phi1 coefficient. How does this change the ACF?
## Now repeat the simulations multiple times to see the distribution of the process
## Number of repetitions
Nrep <- 200
## Length of simulation
N <- 100
## Keep in a matrix
yMat <- matrix(NA,nrow=N,ncol=Nrep)
for(i in 1:Nrep){
  yMat[,i] <- simAR1(phi1=0.9, N=100)
}
## Make a plot of all the simulations
par(mfrow=c(2,1))
plot(yMat[,1],type="n",ylim=range(yMat), xlab="t", ylab="y")
for(i in 1:Nrep){
  lines(yMat[,i])
}
## A box plot for each time point
boxplot(t(yMat))
## Question: Repeat simulations with a non-stationary AR process (phi1 >= 1)
## Does this change the distribution depending on the time? How?
## Generate data from a very simple process
N <- 10
x <- 1:N
y <- x + rnorm(N,mean=2,sd=1)
## An under-fitted model would be a constant, which we can 
## fit with LS (described later in text)
underfitted <- lm(y ~ 1)
## An over-fitted model could for example be the model which 
## simply look up the data we have
overfitted <- function(xnew,x,y){
  ## Find the y value closest to the data in x
  return(y[which.min(abs(xnew-x))])
}
## The suitable model, is in this case not difficult to find since 
## we know the process which generated the data
suitable <- lm(y ~ x)

## Plot the three models
xseq <- seq(min(x),max(x),len=N*10)
plot(x,y)
lines(xseq, sapply(xseq,overfitted,x=x,y=y), col="red")
lines(xseq, predict(underfitted,newdata=data.frame(x=xseq)), col="blue")
lines(xseq, predict(suitable,newdata=data.frame(x=xseq)), col="green")
legend("bottomright", c("Observed output","under-fitted model",
       "over-fitted model","suitable model"), lty=c(0,1,1,1),
       pch=c(1,-1,-1,-1), col=c("black","blue","red","green"))
## The important point is that if we try to measure how well they 
## fit the data, for example with the R^2
## R^2 indicate how well the model fits data and is between 
## zero (a model as poor as the constant model) and one (a perfect model)
rSquared <- function(ypred,x,y){
  1 - sum((y - ypred)^2) / sum((y-mean(y))^2)
}

## The under-fitted model
rSquared(predict(underfitted,newdata=data.frame(x=x)),x,y)
## The over-fitted has a perfect prediction of the data
rSquared(sapply(x,overfitted,x=x,y=y),x,y)

## Hence if we just looked at this we would conclude that the over-fitted 
## model was very good!
## However when we try to predict new data from the same process
ynew <- x + rnorm(N,mean=2,sd=1)
## Then neither the under-fitted nor over-fitted are the best
rSquared(predict(underfitted,newdata=data.frame(x=x)),x,y)
rSquared(sapply(x,overfitted,x=x,y=ynew),x,y)

## Then the suitable model is the best to predict the new data
rSquared(predict(suitable,newdata=data.frame(x=x)),x,y)

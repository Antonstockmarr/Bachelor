files <- dir("functions/", pattern="/*")
for(h in 1:length(files))
{
    if(length(grep("~|#", files[h])) == 0)
      {
        source(paste("functions/", files[h], sep=""))
        print(paste("Sourced:",files[h]))
      }
}

asSeconds <- function(x){as.double(x,units="secs")}

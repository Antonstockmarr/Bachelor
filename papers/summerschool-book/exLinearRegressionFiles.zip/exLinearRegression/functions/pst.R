## Paste helper functions
pst <- function(...){paste(..., sep="")}

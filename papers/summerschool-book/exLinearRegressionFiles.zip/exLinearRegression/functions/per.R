per <- function(tstart,time,tend)
{
  asP(tstart) < time & time <= asP(tend)
}

asHours <- function(x){as.double(x,units="hours")}

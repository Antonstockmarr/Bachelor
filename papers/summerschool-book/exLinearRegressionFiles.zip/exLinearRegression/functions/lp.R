## The simplest low pass filter with only one pole
lpOnePole <- function(x,coefList,returnName=FALSE)
  {
    if(returnName) return("lpOnePole")
    ## Take the coefficients, they have to be in coefList.
    a1 <- coefList$a1
    ## Make a 1'st order low pass filter as (5.3) p.46 in the HAN report.
    #x <- rnorm(30)
    #x[10:20] <- NA
    #a1 <- 0.93
    y <- numeric(length(x))
    y[1] <- x[1]
    for(i in 2:length(x))
      {
        if( is.na(y[i-1]) & !is.na(x[i-1]) )
          {
            y[i] <- a1*x[i-1] + (1-a1)*x[i]
          }else
          {
            y[i] <- a1*y[i-1] + (1-a1)*x[i]
          }
      }
    return(y)
  }

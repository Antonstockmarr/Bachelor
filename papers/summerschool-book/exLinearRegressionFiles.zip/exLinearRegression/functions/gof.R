gof <- function()
  {
    graphics.off()
  }

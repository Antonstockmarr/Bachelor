mae <- function(x)
  {
    mean(abs(x),na.rm=TRUE)
  }

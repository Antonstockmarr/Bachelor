##----------------------------------------------------------------
## Initialize
## Remove all variables in the R environment
rm(list=ls())
## Get the default plotting parameters list
p <- par(no.readonly=TRUE)
## Set the working directory. This should point to the folder where this script is located
## In RStudio use the menu: "Session->Set Working Directory->To Source File Location" (copy to the script)
setwd(".")
## Source the helping functions by running all scripts in the "functions" folder
source("sourceFunctions.R")
##----------------------------------------------------------------


##----------------------------------------------------------------
## Start the modeling
## Read the data into a data.frame. This is hourly average values.
X1 <- read.table("soenderborg1hour.csv", sep=",", header=TRUE, as.is=TRUE)
## Convert the time from character to POSIXct, which is the class in R for representing time
X1$t <- as.POSIXct(X1$t,tz="GMT")

## Set which house to use
ihouse <- 1
X1$P <- X1[ ,paste0("P",ihouse)]

## Resample to 2-days values with the helping function, see the file "functions/resample.R"
X <- resampleDF(X1, 48*3600, asP("2009-12-01"))
##----------------------------------------------------------------


##----------------------------------------------------------------
## Exploratory analysis

## Summary of the data
summary(X[ ,c("P","Te","G","Ws")])

## Time-series plot, here using a helping plot function in "functions/setpar.R"
setpar("ts", mfrow=c(4,1))
plot(X$t, X$P, type="l")
plot(X$t, X$Te, type="l")
plot(X$t, X$G, type="l")
plot(X$t, X$Ws, type="l")
axis.POSIXct(1, X$t, xaxt="s")
## Reset plotting parameters
par(p)

## Scatter plots of the data
pairs(X[ ,c("P","Te","G","Ws")], panel=panel.smooth)
par(p)

## Note the non-linear part of the function between P and Te, remove the summer period
## First make a TRUE-FALSE statement
isummer <- asP("2010-04-01")<X$t & X$t<asP("2010-10-15")
isummer
## One could also remove all data where the ambient temperature is above e.g. 10 degrees by "isummer <- X$Te>10"
## Set all the values, except the time, which is the first column, to NA
X[isummer,-1] <- NA
## Try to do the time series and scatter plots above again
##----------------------------------------------------------------


##----------------------------------------------------------------
## Question 1: First steps in modelling the heat load
## Fit the most simple model by estimating the parameters with linear regression lm()
## The model is specified as a Formula (see ?formula), which per default has an intercept (put "-1" for no intercept)
## The result is returned and assigned to the variable "fit".
## P as the output and Te is the input.
fit <- lm(P ~ Te,  X)
## See the help on lm() and look under "Value:" to see what "fit" contains
?lm
## Use summary() to see a summary of the result
summary(fit)
## The "Estimate" is the estimated value and "Std. Error" is the standard deviation of the parameter estimates, Equation (3.25) in the TS book.
## The "Pr(>|t|)" is the p-value for the parameter estimates, which indicate if they are significantly different from zero.

## The heat loss coefficient value in (W/K) is now the second coefficient
-fit$coef[2]
## Which could also be accessed by its name with
-fit$coef[ names(fit$coef)=="Te" ]
## or simply
-fit$coef["Te"]

## Calculate an estimate of the indoor temperature (fit$coef[1] is the intercept)
-fit$coef[1]/fit$coef["Te"]

## Plot of the estimated linear functions between P and Te
plot(X$Te, X$P, xlim=c(-10,25), ylim=c(0,10000), main=paste0("House",ihouse), xlab="Ambient temperature (K)", ylab="Heat load (W)") # axis limits are set with "xlim" and "ylim"
abline(h=0, col="grey65")                  # Grey horizontal line
abline(fit, col=2)                         # Add the fitted line, alternatively with "abline(a=fit$coef[1],b=fit$coef[2])"

## For exporting the plot to a pdf file use pdf(), e.g.
## pdf("filepath", height=, width=)
## Remember to close the pdf device with "dev.off()"


##----------------------------------------------------------------
## Question 2: Model selection
## Add more inputs to the model, one by one to see how it improves the model fit
summary(fit2 <- lm(P ~ Te,  X))
## One important point is how to add the wind speed with the "interaction term"
## When this is added Ws coefficient becomes a function of Te
## This is done by adding "Ws*Te" to the formula, see ?formula for details
## This is the same as adding both Ws and the multiplied input WS*Te

## Add more inputs and find the most suitable model, watch if the inputs are significant (i.e. Pr(>|t|) is below 0.05)
## Watch if the "Adjusted R-squared value" increase.
...


## Keep your final model fit for model validation (Keep it in "fitFinal", which is used in the model validation below)
fitFinal <- lm(??,  X)
## Discuss the findings. For example simply by comparing the scatter plots and the found significance of the inputs
## e.g. is it possible to see which inputs are most significant?
## and can correlation between the inputs cause problems for the estimation?
pairs(X[ ,c("P","Te","G","Ws")], panel=panel.smooth)


##----------------------------------------------------------------
## Question 3:
## Model validation
## Since there are missing values in the data, which are set to NA, only the complete cases are used in the estimation. A small trick to get the index (the row number in X) of the residuals
iFit <- as.numeric(names(fitFinal$fitted.values))
## Put them into X$residuals
X$residuals <- NA
X$residuals[iFit] <- fitFinal$residuals

## Analyze the assumptions of i.i.d. normal distributed residuals
## Start a new plotting device and make 2 by 3 plots in it
par(mfrow=c(2,3))
## Error vs. input here Te, try with type="b" to see how the residuals are connected in time
plot(X$Te, X$residuals)#, type="b")
## Time series plot of the residuals
plot(X$t, X$residuals)
## Auto-correlation
acf(fitFinal$residuals)
## Histogram of the residuals
hist(fitFinal$residuals, main=paste0("House",ihouse))
## QQ plot
qqnorm(fitFinal$residuals)
qqline(fitFinal$residuals)

## Plot a scatter plot with the residuals vs. the k-lagged residuals
## to illustrate how the auto-correlation is calculated.
k <- 1
## Make a vector witout the k last elements
xt <- X$residuals[-((nrow(X)-k+1):nrow(X))]
## Make a vector witout the k first elements
xtk <- X$residuals[-(1:k)]
## Scatter plot
plot(xt, xtk, xlab=expression(epsilon[t-k]), ylab=expression(epsilon[t]))
## The correlation betwee x_t-k and x_t
## Try it for different lags k and compare with the ACF calculated above.
cor(xt, xtk, "complete.obs")

## Other relevant plotting:
## Standard plotting for analyzing an lm fit, see "?plot.lm"
plot(fitFinal)


##----------------------------------------------------------------
## Question 4:
## Now try to see what happens when a linear regression model, which do not include the dynamics, is used for hourly data
Xhour <- X1
## Remove the summer period
Xhour[asP("2010-03-15")<Xhour$t & Xhour$t<asP("2010-12-15"),-1] <- NA

## Scatter plots
pairs(Xhour[ ,c("P","Te","G","Ws")])

## Time-series plot
## For a given period
x <- Xhour[asP("2010-02-01")<Xhour$t & Xhour$t<asP("2010-03-01"), ]
setpar("ts", mfrow=c(4,1))
plot(x$t, x$P, type="l")
title(main=paste0("House ",ihouse), line=-1)
plot(x$t, x$Pe, type="l")
plot(x$t, x$Te, type="l")
plot(x$t, x$G, type="l")
plot(x$t, x$Ws, type="l")
axis.POSIXct(1, X$t, xaxt="s")
par(p)

## Fit the model, remember to only include all significant parameters here
fitFinal <- lm(P ~ Te + G + Ws:Te,  Xhour)
summary(fitFinal)

## Validate the model to conclude whether we can validate the model and thereby trust the parameter estimates?
## Analyze the residuals
iFit <- as.numeric(names(fitFinal$fitted.values))
## Put them into X$residuals
Xhour$residuals <- NA
Xhour$residuals[iFit] <- fitFinal$residuals
Xhour$Phat <- NA
Xhour$Phat[iFit] <- fitFinal$fitted.values

## See the lagged scatter plot
k <- 1
## Two plots
par(mfrow=c(1,2))
## Plot it
plot(Xhour$residuals[-((nrow(Xhour)-k+1):nrow(Xhour))], Xhour$residuals[-(1:k)], xlab=expression(epsilon[t-k]), ylab=expression(epsilon[t]), main=paste("k=",k))
## The auto-correlation
acf(Xhour$residuals, na.action=na.exclude)
par(p)

## Time-series plot
## For a given period
x <- Xhour[asP("2010-02-01")<Xhour$t & Xhour$t<asP("2010-03-01"), ]
## Make 5 plots
setpar("ts", mfrow=c(5,1))
## The measured heat load
plot(x$t, x$P, type="l")
## Add the predicted heat load
lines(x$t, x$Phat, col=2)
## Put a legend on the plot
legend("topright", c("P","Phat"), lty=1, col=1:2, bg="grey95")
## Put a heading on the plot
title(main=paste0("House ",ihouse), line=-1)
## Plot the inputs
plot(x$t, x$Te, type="l")
plot(x$t, x$G, type="l")
plot(x$t, x$Ws, type="l")
plot(x$t, x$Ws*x$Te, type="l")
axis.POSIXct(1, x$t, xaxt="s")
par(p)

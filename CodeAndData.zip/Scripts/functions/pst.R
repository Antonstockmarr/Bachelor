## Paste helper functions
pst <- function(...) {
    paste0(...)
}

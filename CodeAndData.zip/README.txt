Dette inkluderer en kort beskrivelse af hvad, hvert script g�r.
For at vores kode virker, skal dataen for hvert hus, ligge i "Consumption Data" mappen som i Zip-filen her.
Derudover skal vejrdata og BBR-data ligge som det g�r i Zip-filen og navnene �ndres manuelt i "data.R" scriptet.

For at f� vores resultater ud, k�res "MultipleRegression.R" for Wind dependency plots,
og "Predictions.R" for forecast af januar-data b�de p� dags og timeniveau.

De brugte R-pakker, der er brugt, er:

library(xts)
library(solaR)
library(ggplot2) 
library(gridExtra)
library(tidyverse)
library(grid)
library(GGally)
library(marima)
library('fields')
library('reshape2')

Herunder ses en liste af alle scripts i alfabetisk r�kkef�lge med en kort forklaring af hvad der sker i dem.

Armax_model.R
Dette script unders�ger om det er muligt med en marima (n,0,1)-model om man kan f� et bedre HCL estimat.
I linje 21 gemmes index p� de huse, der unders�ges i scriptet. S� l�ber scriptet igennem (1,0,1) til (4,0,1) modeller.
S� plottes HCL med standard-deviations som ogs� ses i rapporten, f�rst uden, s� med Fourier-r�kker.
Dette script er modificeret p� baggrund af et script udafbejdet af Peder Bacher, som ogs� har givet os "functions" mappen, der bliver brugt i dette script.

BreakPoint.R
Et kort script, som gennemg�r vores approach, p� hvordan vi endte med at inddele vinterperioden til 12 grader.

BSplines.R
En funktion, der laver vores spline-basis for vindretningerne, s� det er nemt at konvertere grader til N, E, S & W, som bruges i modellen for daily data.

CirclePlot.R
En funktion, der laver vores "Sommerfugleplot", som bliver k�rt i "MultipleRegression.R" scriptet.

data.R
Denne fil loader alt data, fra en mappe kaldt "Consumption data", der ligger i samme mappe som "Scripts" mappen.
Denne fil tilf�jer attributes for weekend, og ferier (som skal inds�ttes manuelt for fremtidige ferier).
Derudover aggregates daily data, b�de for husene og for weather data, som ogs� loades i dette script.
Weahter dataens fil skal ligge i for�ldremappen og hedder lige nu "WeatherData_01-01-2018_02-06-2019.csv", dette filnavn �ndres manuelt.
Derudover sker der sm�ting i dette script, s�som Datachecking, n gemmes som antallet af huse der "best�r" datachecking.
OBS! Her cuttes februar ud, da data i februar er langt fra stabilt nok (det starter med et hul p� 5 dage, efterfulgt af kun 3 dages data).

DataChecking.R
En funktion, der kort tjekker om der er mindst 1000 data-punkter med h�jst 1/20 af dem v�rende NA's.

exploratory.R
Et script, der kigger n�rmere p� data, og plotter diverse plots, der er med i rapporten.

HourData.R
Et script, der laver heatmaps af de forskellige huses avg consumption i vinter og sommerperioden samt hele �ret.
Derudover laves der et par plots til rapporten. Det store for-loop skal kun k�res en gang, da det tager lang tid.
Vi har k�rt det for vores data og vedlagt det allerede.

MultipleRegression.R
Dette script danner "Sommerfugleplots" for hvert hus, samt det mere matematiske wind dependency plot.
Derudover gemmes to plots i "figures" mappen, og der gemmes nogle stjernetabeller i csv-filer.

Polarize.R
En funktion til at polarisere x,y-koordinater, denne bliver brugt til at aggregate Wind data til dagsv�rdier i "data.R"

Predictions.R
Et script, der laver forudsigelser for b�de daily values og hourly values.
Dette script plotter i mellemtiden b�de App-forslag og mere statisiske plots for hvert hus, samt vejrdata for prediction-perioden.

SimpleRegression.R
Et script, der fitter en line�r model mellem forbrug og temperatur for hvert hus.

Sun.R
En meget kort funktion, der danner SolarRadiation attributen, som bruger solaR pakken fra R.

TrainTest.R
En funtion der tager en liste af dataframes, og opdeler det i tr�ning og tests�t, som en liste af 2 lister af dataframes.
